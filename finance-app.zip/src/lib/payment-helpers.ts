import { CURRENCY_SYMBOLS } from "@/constants";

export function formatTransactionAmount(payment: any) {
  if (payment.displayAmountFormatted) {
    return payment.displayAmountFormatted;
  }

  const currency =
    payment.displayCurrency ||
    payment.providerCurrency ||
    payment.currency ||
    "NGN";
  const amount = payment.displayAmount ?? payment.providerAmount ?? 0;

  const symbol = CURRENCY_SYMBOLS[currency] || `${currency} `;

  return `${symbol}${Number(amount || 0).toLocaleString("en-US", {
    maximumFractionDigits: 2,
  })}`;
}
