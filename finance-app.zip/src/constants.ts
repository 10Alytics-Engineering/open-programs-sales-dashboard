export const USER_ROLES = [
  { value: "USER", label: "User" },
  { value: "COURSE_ADMIN", label: "Course Admin" },
  { value: "ADMIN", label: "Admin" },
  { value: "SUPER_ADMIN", label: "Super Admin" },
  { value: "FINANCE_ADMIN", label: "Finance Admin" },
];

export const CURRENCY_SYMBOLS: Record<string, string> = {
  NGN: "₦",
  GHS: "₵",
  ZAR: "R",
  KES: "KSh",
  UGX: "USh",
  RWF: "FRw",
  USD: "$",
  GBP: "£",
};
